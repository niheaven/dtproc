#ifndef __RMYSQL_TYPES__
#define __RMYSQL_TYPES__

#include "MyConnection.h"
#include "MyResult.h"
#include "MyBinding.h"

#endif
