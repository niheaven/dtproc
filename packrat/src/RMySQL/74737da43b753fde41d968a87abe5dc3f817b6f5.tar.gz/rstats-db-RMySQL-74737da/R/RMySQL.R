#' @useDynLib RMySQL
#' @importFrom Rcpp sourceCpp
"_PACKAGE"
