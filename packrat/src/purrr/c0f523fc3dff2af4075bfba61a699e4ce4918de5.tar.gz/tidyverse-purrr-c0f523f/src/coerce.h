#ifndef UTILS_H
#define UTILS_H

// Set value of to[i] to from[j], coercing vectors using usual rules.
void set_vector_value(SEXP to, int i, SEXP from, int j);


#endif
