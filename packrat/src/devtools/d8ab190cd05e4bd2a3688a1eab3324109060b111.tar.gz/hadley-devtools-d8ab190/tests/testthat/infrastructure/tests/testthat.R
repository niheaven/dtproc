library(testthat)
library(infrastructure)

test_check("infrastructure")
